/* 
    CIT 281 Project 2
    Payton Lommers
*/

// Returns a random number between min (inclusive) and max (exclusive)
const getRandomInteger = function(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

// Returns a random lowercase letter from a-z
const getRandomLetter = function() {
    const alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    return alphabet[getRandomInteger(0, 26)];
}

// Returns a string of random length between minLength and maxLength. Characters are also randomized via getRandomLetter
const getRandomString = function(minLength, maxLength) {
    let result = "";
    for (let i = 0; i < getRandomInteger(minLength, maxLength + 1); i++) {
        result += getRandomLetter();
    }
    return result;
}

// Accepts a string, returns a string with characters sorted alphabetically
const getSortedString = function(string) {
    return string.split("").sort().join("");
}

console.log(getRandomString(10, 20));